
# coding: utf-8

# 资本化程度=全市场总市值/gdp（当年的gdp目标值，上一年的gdp*当年预计的增速目标）

# In[110]:


import pandas as pd
import numpy as np
total_share=pd.read_csv('/home/yang/下载/daily/daily_otj/daily_stock/total_share.csv')
volume=pd.read_csv('/home/yang/下载/daily/daily_otj/daily_stock/volume.csv')
vwap=pd.read_csv('/home/yang/下载/daily/daily_otj/daily_stock/vwap.csv')


# In[111]:


total_share_array=np.array(total_share)
volume_array=np.array(volume)
vwap_array=np.array(vwap)

where_are_nan = np.isnan(total_share_array)
total_share_array[where_are_nan] = 0 
where_are_nan = np.isnan(volume_array)
volume_array[where_are_nan] = 0 
where_are_nan = np.isnan(vwap_array)
vwap_array[where_are_nan] = 0 

capitalization=[]
for i in range(total_share.shape[0]):
    capitalization.append([int(total_share_array[i,0]),sum(total_share_array[i,1:]*volume_array[i,1:])])


# In[112]:


capitalization_year=[]
j=0
for i in range(total_share.shape[0]):
    if j == 0:
        capitalization_year.append(capitalization[i])
        j=j+1
    else:
        if int(capitalization[i][0]/10000)==int(capitalization_year[j-1][0]/10000):
            capitalization_year[j-1][1]=capitalization_year[j-1][1]+capitalization[i][1]
        else:
            capitalization_year.append(capitalization[i])
            j=j+1
capitalization_year    


# In[113]:


data=pd.read_excel('/home/yang/下载/macro.xlsx')


# In[114]:


data


# In[115]:


data['指标名称'] = data['指标名称'].map(lambda x: str(x)[:10])
data_need=data.drop(['M0','M1','M2','GDP:现价:当季值','GDP:现价','政府预期目标:GDP:同比','预测平均值:GDP:同比','金融机构:各项存款余额','金融机构:外汇各项存款余额'],axis=1)


# In[116]:


for i in range(239):
    data_need = data_need.drop([i])
data_need


# In[117]:


import re
data_gdp_array=np.array(data_need)
for i in range(data_gdp_array.shape[0]):
    data_gdp_array[i,0]=re.sub('[-]','',data_gdp_array[i,0])


# In[118]:


data_gdp_array_year=[]
j=0
for i in range(data_gdp_array.shape[0]):
    if int(data_gdp_array[i][0][4:6])==12:
        if data_gdp_array[i][1] !=0:
            data_gdp_array_year.append([int(data_gdp_array[i][0]),data_gdp_array[i][1]])
data_gdp_array_year


# In[119]:


capitalization_year


# In[120]:


result_long_year_list=[]
result_capitalization_list=[]
for i in range(len(capitalization_year)):
    result_long_year_list.append(int(capitalization_year[i][0]/10000))
    result_capitalization_list.append(capitalization_year[i][1]/data_gdp_array_year[i][1])


# In[121]:


result_df = pd.DataFrame({'long_year':result_long_year_list,'capitalization':result_capitalization_list})
result_df


# In[122]:


columns=['long_year','capitalization']
result_df.to_csv('/home/yang/dian/out/资本化程度（预测平均值）.csv',index=False,columns=columns)

