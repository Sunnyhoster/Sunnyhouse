
# coding: utf-8

# In[105]:


import pandas as pd

data=pd.read_excel('/home/yang/下载/股票/社会短期债务滚动系数与居民短期流动性充裕指标.xls')


# In[106]:


data


# In[107]:


data2=data.drop(['社会融资规模:新增人民币贷款:当月值','金融机构:各项贷款余额','1年期贷款基准利率:月'],axis=1)


# In[108]:


data2


# In[109]:


data2.columns = ['long_date','result']


# In[110]:


data2


# In[111]:


data2 = data2.drop([0,195,196])


# In[112]:


data2


# In[113]:


data2['long_date'] = data2['long_date'].map(lambda x: str(x)[:10])


# In[114]:


data2


# In[117]:


data2.to_csv('/home/yang/dian/out/社会短期债务滚动系数.csv',index=False)

