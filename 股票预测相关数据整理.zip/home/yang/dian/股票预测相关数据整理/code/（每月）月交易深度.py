
# coding: utf-8

# In[167]:


import pandas as pd
import numpy as np
data=pd.read_excel('/home/yang/下载/macro.xlsx')


# In[168]:


data['指标名称'] = data['指标名称'].map(lambda x: str(x)[:10])
data_need=data.drop(['M0','M1','GDP:现价:当季值','GDP:现价','预测平均值:GDP:当季同比','预测平均值:GDP:同比','政府预期目标:GDP:同比','金融机构:各项存款余额','金融机构:外汇各项存款余额'],axis=1)


# In[169]:


for i in range(239):
    data_need = data_need.drop([i])


# In[170]:


m2_mean=data_need['M2'].mean()


# In[171]:


import re
data_m2_year_array=np.array(data_need)
data_m2_year_list = []
for i in range(data_m2_year_array.shape[0]):
    if data_m2_year_array[i,1]==0:
        data_m2_year_array[i,1]=m2_mean
    data_m2_year_array[i,0]=re.sub('[-]','',data_m2_year_array[i,0])


# In[172]:


data_m2_year_array


# In[173]:


data_volume=pd.read_csv('/home/yang/下载/daily/daily_otj/daily_stock/volume.csv')
data_volume2 = np.array(data_volume)
where_are_nan = np.isnan(data_volume2)
data_volume2[where_are_nan] = 0 
volume_sum=[]
for i in range(data_volume2.shape[0]):
    volume_sum.append([int(data_volume2[i,0]),sum(data_volume2[i,1:])])


# In[174]:


volume_sum


# In[175]:


volume_month=[]
j=0
for i in range(data_volume2.shape[0]):
    if j ==0:
        volume_month.append(volume_sum[i])
        j=j+1
    else:
        if int(volume_sum[i][0]/100)==int(volume_month[j-1][0]/100):
            volume_month[j-1][1]=volume_month[j-1][1]+volume_sum[i][1]
        else:
            volume_month.append(volume_sum[i])
            j=j+1
volume_month


# In[176]:


j=0
for i in range(len(volume_month)):
    flag=0
    while flag==0:
        if int(data_m2_year_array[j][0][0:6])==int(volume_month[i][0]/100):
            volume_month[i].append(data_m2_year_array[j][1])
            flag=1
        else:j=j+1
            
data_m2_year_array[0:5]


# In[177]:


volume_month


# (每日日交易深度=日交易量*365/m2)

# In[179]:


for i in range(len(volume_month)):
    volume_month[i].append(volume_month[i][1]/volume_month[i][2])


# In[180]:


volume_month


# In[181]:


result_long_year_list=[]
result_month_deep_list=[]
for i in range(len(volume_month)):
    result_long_year_list.append(volume_month[i][0])
    result_month_deep_list.append(volume_month[i][3])


# In[182]:


result_df = pd.DataFrame({'long_year':result_long_year_list,'month_deep':result_month_deep_list})
result_df


# In[183]:


columns=['long_year','month_deep']
result_df.to_csv('/home/yang/dian/out/（每月）月交易深度.csv',index=False,columns=columns)

