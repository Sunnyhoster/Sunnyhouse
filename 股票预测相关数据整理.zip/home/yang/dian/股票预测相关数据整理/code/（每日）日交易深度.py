
# coding: utf-8

# In[74]:


import pandas as pd
import numpy as np
data=pd.read_excel('/home/yang/下载/macro.xlsx')


# In[75]:


data['指标名称'] = data['指标名称'].map(lambda x: str(x)[:10])
data_need=data.drop(['M0','M1','GDP:现价:当季值','GDP:现价','预测平均值:GDP:当季同比','预测平均值:GDP:同比','政府预期目标:GDP:同比','金融机构:各项存款余额','金融机构:外汇各项存款余额'],axis=1)


# In[76]:


for i in range(239):
    data_need = data_need.drop([i])


# In[77]:


m2_mean=data_need['M2'].mean()


# In[78]:


import re
data_m2_year_array=np.array(data_need)
data_m2_year_list = []
for i in range(data_m2_year_array.shape[0]):
    if data_m2_year_array[i,1]==0:
        data_m2_year_array[i,1]=m2_mean
    data_m2_year_array[i,0]=re.sub('[-]','',data_m2_year_array[i,0])


# In[79]:


data_m2_year_array


# In[80]:


data_volume=pd.read_csv('/home/yang/下载/daily/daily_otj/daily_stock/volume.csv')
data_volume2 = np.array(data_volume)
where_are_nan = np.isnan(data_volume2)
data_volume2[where_are_nan] = 0 
volume_sum=[]
for i in range(data_volume2.shape[0]):
    volume_sum.append([int(data_volume2[i,0]),sum(data_volume2[i,1:])*365])
volume_sum


# In[81]:


j=0
for i in range(data_volume2.shape[0]):
    flag=0
    while flag==0:
        if int(data_m2_year_array[j][0][0:6])==int(volume_sum[i][0]/100):
            volume_sum[i].append(data_m2_year_array[j][1])
            flag=1
        else:j=j+1


# In[82]:


volume_sum


# (每日日交易深度=日交易量*365/m2)

# In[83]:


for i in range(data_volume2.shape[0]):
    volume_sum[i].append(volume_sum[i][1]/volume_sum[i][2])


# In[84]:


volume_sum


# In[85]:


result_long_year_list=[]
result_day_deep_list=[]
for i in range(data_volume2.shape[0]):
    result_long_year_list.append(volume_sum[i][0])
    result_day_deep_list.append(volume_sum[i][2])


# In[88]:


result_df = pd.DataFrame({'long_year':result_long_year_list,'day_deep':result_day_deep_list})
result_df


# In[89]:


columns=['long_year','day_deep']
result_df.to_csv('/home/yang/dian/out/（每日）日交易深度.csv',index=False,columns=columns)

